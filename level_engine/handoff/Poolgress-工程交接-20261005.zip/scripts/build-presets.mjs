import fs from 'node:fs';
import path from 'node:path';
const source=process.argv[2];
if(!source)throw Error('Pass the existing drill/levels directory');
const entries=fs.readdirSync(source).filter(n=>n.endsWith('.json')).sort().map(file=>{
 const data=JSON.parse(fs.readFileSync(path.join(source,file),'utf8')).data;
 const id=Number(file.slice(0,2));
 if(id===20){data.note.order=true;data.note.no_contact=true;}
 return {id,data};
});
fs.writeFileSync(new URL('../dist/editor/presets.js',import.meta.url),'window.COACH_PRESETS = '+JSON.stringify(entries,null,2)+';\n');
